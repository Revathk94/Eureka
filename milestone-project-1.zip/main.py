movies=[]

def movie_add():
    title=input("Enter the movie title: ")
    director=input("Enter the movie director: ")
    year=input("Enter the movie release year: ")
    movies.append({
    'title':title,
    'director':director,
    'year':year
    })

def movie_list():
    for movie in movies:
        print("The movie "+movie["title"].title()+" was directed by "+movie["director"].title()+" in the year "+movie["year"])

def movie_find():
    movie_name=input("Enter the name of the movie you want to find :")
    for movie in movies:
        #print(movie["title"])
        #print(movie_name)
        if movie_name == movie["title"]:
            print("The movie you searched for "+movie["title"].title()+" which is directed by "+movie["director"].title()+" in the year "+movie["year"])
            

MENU_PROMPT="\nEnter 'a' to add a movie, 'l' to see your movies, 'f' to find a movie by title, or 'q' to quit:"
selection=input(MENU_PROMPT)
while selection!='q':
    if selection=='a':
        movie_add()
    elif selection=='l':
        movie_list()
    elif selection=='f':
        movie_find()
    else:
        print("Unknown command. Please try again.")
    selection=input(MENU_PROMPT)



